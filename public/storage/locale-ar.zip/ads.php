<?php

return [
    'name'       => 'Ads',
    'create'     => 'New ads',
    'edit'       => 'Edit ads',
    'location'   => 'Location',
    'url'        => 'URL',
    'expired_at' => 'Expired at',
    'key'        => 'Key',
    'shortcode'  => 'Shortcode',
    'clicked'    => 'Clicked',
    'not_set'    => 'Not set',
];
