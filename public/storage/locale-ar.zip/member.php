<?php

return [
    'dob' => 'Born :date',
    'draft_posts' => 'Draft Posts',
    'pending_posts' => 'Pending Posts',
    'published_posts' => 'Published Posts',
    'posts' => 'Posts',
    'write_post' => 'Write a post',
];
