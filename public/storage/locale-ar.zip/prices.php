<?php

return [
    'name'   => 'Price',
    'create' => 'New price',
    'edit'   => 'Edit price',
    'list'   => 'List price',
];
