<?php

return [
    'name'   => 'Product tags',
    'create' => 'New product tag',
    'edit'   => 'Edit product tag',
];
